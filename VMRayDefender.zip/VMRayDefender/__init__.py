"""
init.py

This module provides a set of functions for communicating with the Luminar
API. The main purpose of these functions is
to retrieve and process security indicators and leaked credentials from
Luminar, transform them into a compatible format
, and save them into Azure Sentinel.

Main components:

LuminarManager: This class manages interactions with the Luminar API. It is
responsible for requesting and refreshing
access tokens, as well as managing the connection status.

process_malware, enrich_malware_items, enrich_incident_items: These functions
process malware and incident items and
create enriched data for each.

create_data, get_static_data: These functions transform raw indicators into a
format compatible with Azure Sentinel.

luminar_api_fetch: This function fetches data from the Luminar API, processes
the fetched items, and manages
relationships between items.

main: This function handles Luminar API requests. It initializes the Luminar
manager, requests and refreshes access
tokens, manages Luminar API calls, and handles pagination to ensure all pages
of data are retrieved. A timer trigger
allows it to run at specified intervals.

This module is designed for use as part of an Azure Function App and requires
certain environment variables to be set.
"""
import json
import os
import requests
from ipaddress import ip_network
from os import environ
import logging
import azure.functions as func
from .state_manager import StateManager
from .const import *
from .lib.MicrosoftDefender import MicrosoftDefender
from .lib.VMRay import VMRay
from .lib.Models import Machine

subscriptionID = environ.get("AzureSubscriptionID")
resourceGroupName = environ.get("AzureResourceGroupName")
workspaceName = environ.get("AzureWorkspaceName")
workspaceID = environ.get("WorkspaceID")
clientID = environ.get("AzureClientID")
clientSecret = environ.get("AzureClientSecret")
tenant_id = environ.get("AzureTenantID")
vmraySampleVerdict = environ.get("vmraySampleVerdict")
vmrayInitialFetchDate = environ.get("vmrayInitialFetchDate")
state = StateManager(environ.get("AzureWebJobsStorage"))
session = requests.Session()


TIMEOUT = 60.0
# There's a limit of 100 tiIndicators per request.
MAX_TI_INDICATORS_PER_REQUEST = 100
ENDPOINT = f"https://management.azure.com/subscriptions/{subscriptionID}/resourceGroups/{resourceGroupName}/providers/Microsoft.OperationalInsights/workspaces/{workspaceName}/providers/Microsoft.SecurityInsights/threatIntelligence/main/createIndicator?api-version=2024-03-01"
TOKEN_ENDPOINT = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
VMRAY_BASE_URL = environ.get("vmrayBaseURL")
RESOURCE = "https://management.azure.com"


def group_evidences_by_machines(evidences):
    """
    Helper function to group evidences by machine
    :param evidences: dict of evidence objects
    :return machines: list of machine objects which contains related evidences
    """

    machines = {}

    # iterating only evidence objects of evidences dict
    for evidence in evidences.values():
        # select first machine for live response
        # other machine_ids are used for remediation actions like isolation, av_scan etc
        selected_machine_id = list(evidence.machine_ids)[0]

        # if machine object already created and added to the dict, update the evidences
        if selected_machine_id in machines.keys():

            if evidence.detection_source == ALERT_DETECTION_SOURCE.WINDOWS_DEFENDER_AV:
                machines[selected_machine_id].av_evidences[evidence.sha256] = evidence
            else:
                machines[selected_machine_id].edr_evidences[evidence.sha256] = evidence

        # otherwise create machine object, append evidence and add it to the dict
        else:
            machine = Machine(selected_machine_id)

            if evidence.detection_source == ALERT_DETECTION_SOURCE.WINDOWS_DEFENDER_AV:
                machine.av_evidences[evidence.sha256] = evidence
            else:
                machine.edr_evidences[evidence.sha256] = evidence

            machines[selected_machine_id] = machine
    return list(machines.values())


def update_evidence_machine_ids(machines):
    evidences_by_machine = {}

    for machine in machines:

        for evidence in machine.edr_evidences.values():
            if evidence.sha256 in evidences_by_machine:
                evidences_by_machine[evidence.sha256].add(machine.id)
            else:
                evidences_by_machine[evidence.sha256] = {machine.id}

        for evidence in machine.av_evidences.values():
            if evidence.sha256 in evidences_by_machine:
                evidences_by_machine[evidence.sha256].add(machine.id)
            else:
                evidences_by_machine[evidence.sha256] = {machine.id}

    for machine in machines:
        for evidence in machine.edr_evidences.values():
            evidence.machine_ids = evidences_by_machine[evidence.sha256]

        for evidence in machine.av_evidences.values():
            evidence.machine_ids = evidences_by_machine[evidence.sha256]

    return machines


def run(alert):    
    # Initializing and authenticating api instances
    md = MicrosoftDefender(logging)
    vmray = VMRay(logging)

    if md.config.INGESTION.AV_BASED_INGESTION:
        # Uploading helper script to library
        helper_script_status = md.upload_ps_script_to_library()

    # Dict of evidences which found on VMRay database
    found_evidences = {}

    # Dict of evidences which need to be downloaded from Microsoft Defender for Endpoint
    download_evidences = {}

    # Dict of evidences which found on VMRay database but will be resubmitted
    resubmit_evidences = {}

    # Retrieving alerts from Microsoft Defender for Endpoint
    evidences = md.get_evidences(alert.get('id'))

    # Checking hash values in VMRay database, if evidence is found on VMRay no need to submit again
    for sha256 in evidences:
        sample = vmray.get_sample(sha256)
        if sample is not None:
            # If resubmission is active and evidence verdict in configured resubmission verdicts
            # Evidence added into resubmit evidences and re-analyzed
            evidence_metadata = vmray.parse_sample_data(sample)

            if VMRayConfig.RESUBMIT and evidence_metadata["sample_verdict"] in VMRayConfig.RESUBMISSION_VERDICTS:
                log.info("File %s found in VMRay database, but will be resubmitted." % sha256)
                resubmit_evidences[sha256] = evidences[sha256]
                evidences[sha256].need_to_submit = True
            else:
                log.info("File %s found in VMRay database. No need to submit again." % sha256)
                # if evidence found on VMRay we need to store sample metadata in Evidence object
                evidences[sha256].vmray_sample = sample
                found_evidences[sha256] = evidences[sha256]
        else:
            download_evidences[sha256] = evidences[sha256]
            evidences[sha256].need_to_submit = True

    if len(found_evidences) > 0:
        log.info("%d evidences found on VMRay" % len(found_evidences))

    if len(resubmit_evidences) > 0:
        log.info("%d evidences found on VMRay, but will be resubmitted." % len(resubmit_evidences))

    # Combine download_evidences dict and resubmit_evidences dict for submission
    download_evidences.update(resubmit_evidences)

    if len(download_evidences) > 0:
        log.info("%d evidences need to be downloaded and submitted" % len(download_evidences))

    if md.config.INDICATOR.ACTIVE:
        # Retrieving indicators from Microsoft Defender for Endpoint to check duplicates
        old_indicators = md.get_indicators()

    if not VMRayConfig.RESUBMIT:

        # Retrieving indicators from VMRay Analyzer for found evidences
        for evidence in found_evidences.values():

            sample_data = vmray.parse_sample_data(evidence.vmray_sample)

            # If sample identified as suspicious or malicious we need to extract indicator values and import them to Microsoft Defender for Endpoint
            if sample_data["sample_verdict"] in GeneralConfig.SELECTED_VERDICTS:

                if md.config.INDICATOR.ACTIVE:
                    # Retrieving and parsing indicators
                    sample_iocs = vmray.get_sample_iocs(sample_data)
                    ioc_data = vmray.parse_sample_iocs(sample_iocs)

                    # Creating Indicator objects with checking old_indicators for duplicates
                    indicator_objects = md.create_indicator_objects(ioc_data, old_indicators)

                    # Submitting new indicators to Microsoft Defender for Endpoint
                    md.submit_indicators(indicator_objects)

                if evidence.detection_source == ALERT_DETECTION_SOURCE.WINDOWS_DEFENDER_AV:
                    if md.config.AV_ENRICHMENT.ACTIVE:
                        # Retrieving and parsing sample vtis from VMRay Analyzer
                        vti_data = vmray.get_sample_vtis(sample_data["sample_id"])
                        sample_vtis = vmray.parse_sample_vtis(vti_data)

                        # Enriching alerts with vtis and sample metadata
                        md.enrich_alerts(evidence, sample_data, sample_vtis, md.config.AV_ENRICHMENT.SELECTED_SECTIONS)
                else:
                    if md.config.EDR_ENRICHMENT.ACTIVE:
                        # Retrieving and parsing sample vtis from VMRay Analyzer
                        vti_data = vmray.get_sample_vtis(sample_data["sample_id"])
                        sample_vtis = vmray.parse_sample_vtis(vti_data)

                        # Enriching alerts with vtis and sample metadata
                        md.enrich_alerts(evidence, sample_data, sample_vtis, md.config.EDR_ENRICHMENT.SELECTED_SECTIONS)

                # Running automated remediation actions based on configuration
                md.run_automated_machine_actions(sample_data, evidence)

    # Group evidences by machines for gathering evidence files with live response
    machines = group_evidences_by_machines(evidences)

    # Update evidence machine ids to process multiple evidences in different machines
    machines = update_evidence_machine_ids(machines)
    log.info("%d machines contains evidences" % len(machines))

    if md.config.INGESTION.AV_BASED_INGESTION:
        if helper_script_status:
            machines = md.run_av_submission_script(machines)
            machines = vmray.get_av_submissions(machines)
            for machine in machines:
                if machine.run_script_live_response_finished:
                    for evidence in machine.av_evidences.values():
                        if len(evidence.submissions) > 0:
                            evidence.submissions = [evidence.submissions[0]]
                            # Waiting and processing submissions
                            for result in vmray.wait_submissions(evidence.submissions):
                                submission = result["submission"]
                                evidence = submission["evidence"]
                                vmray.check_submission_error(submission)

                                if result["finished"]:
                                    sample = vmray.get_sample(submission["sample_id"], True)
                                    sample_data = vmray.parse_sample_data(sample)

                                    # If sample identified as suspicious or malicious we need to extract IOC values and import them to Microsoft Defender for Endpoint
                                    if sample_data["sample_verdict"] in GeneralConfig.SELECTED_VERDICTS:

                                        if md.config.INDICATOR.ACTIVE:
                                            # Retrieving and parsing indicators
                                            sample_iocs = vmray.get_sample_iocs(sample_data)
                                            ioc_data = vmray.parse_sample_iocs(sample_iocs)

                                            # Creating Indicator objects with checking old_indicators for duplicates
                                            indicator_objects = md.create_indicator_objects(ioc_data, old_indicators)

                                            # Submitting new indicators to Microsoft Defender for Endpoint
                                            md.submit_indicators(indicator_objects)

                                        if md.config.AV_ENRICHMENT.ACTIVE:
                                            # Retrieving and parsing sample vtis from VMRay Analyzer
                                            vti_data = vmray.get_sample_vtis(sample_data["sample_id"])
                                            sample_vtis = vmray.parse_sample_vtis(vti_data)

                                            # Enriching alerts with vtis and sample metadata
                                            md.enrich_alerts(evidence, sample_data, sample_vtis, md.config.AV_ENRICHMENT.SELECTED_SECTIONS)

                                        # Running automated remediation actions based on configuration
                                        md.run_automated_machine_actions(sample_data, evidence)

    for machine in machines:
        machine.timeout_counter = 0

    if md.config.INGESTION.EDR_BASED_INGESTION:

        # Running live response job for gathering evidence files from machines
        machines = md.run_edr_live_response(machines)

        # Collect evidence objects which successful live response jobs and download url
        successful_evidences = [evidence for machine in machines for evidence in machine.get_successful_edr_evidences()]
        log.info("%d evidences successfully collected with live response" % len(successful_evidences))

        # Download evidence files from Microsoft Defender for Endpoint
        downloaded_evidences = md.download_evidences(successful_evidences)
        log.info("%d evidence file downloaded successfully" % len(downloaded_evidences))
        if md.config.INDICATOR.ACTIVE:
            # Retrieving indicators from Microsoft Defender for Endpoint to check duplicates
            old_indicators = md.get_indicators()

        # Submitting downloaded samples to VMRay
        submissions = vmray.submit_samples(downloaded_evidences)

        # Waiting and processing submissions
        for result in vmray.wait_submissions(submissions):
            submission = result["submission"]
            evidence = submission["evidence"]
            vmray.check_submission_error(submission)

            if result["finished"]:
                sample = vmray.get_sample(submission["sample_id"], True)
                sample_data = vmray.parse_sample_data(sample)

                # If sample identified as suspicious or malicious we need to extract IOC values and import them to Microsoft Defender for Endpoint
                if sample_data["sample_verdict"] in GeneralConfig.SELECTED_VERDICTS:

                    if md.config.INDICATOR.ACTIVE:
                        # Retrieving and parsing indicators
                        sample_iocs = vmray.get_sample_iocs(sample_data)
                        ioc_data = vmray.parse_sample_iocs(sample_iocs)

                        # Creating Indicator objects with checking old_indicators for duplicates
                        indicator_objects = md.create_indicator_objects(ioc_data, old_indicators)

                        # Submitting new indicators to Microsoft Defender for Endpoint
                        md.submit_indicators(indicator_objects)

                    if md.config.EDR_ENRICHMENT.ACTIVE:
                        # Retrieving and parsing sample vtis from VMRay Analyzer
                        vti_data = vmray.get_sample_vtis(sample_data["sample_id"])
                        sample_vtis = vmray.parse_sample_vtis(vti_data)

                        # Enriching alerts with vtis and sample metadata
                        md.enrich_alerts(evidence, sample_data, sample_vtis, md.config.EDR_ENRICHMENT.SELECTED_SECTIONS)

                    # Running automated remediation actions based on configuration
                    md.run_automated_machine_actions(sample_data, evidence)

        # Removing downloaded files
        for downloaded_evidence in downloaded_evidences:
            os.remove(downloaded_evidence.download_file_path)



def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        alert = req.params.get("alert")
        if not alert:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                alert = req_body.get("alert")
                
        
        logging.info(f"alert {alert.get('id')}")
        run(alert)
        return func.HttpResponse(
            json.dumps({'message': 'Sucessfully submitted and created indicator'}),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)